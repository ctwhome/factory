angular-ionic-requirejs-phonegap-seed
=====================================

Sample PhoneGap / Cordova application built with Angular and Ionic Framework, uses RequireJS for loading scripts. Example controllers, filters, services, directives and config.

Forked from ionic seed (https://github.com/driftyco/ionic-angular-cordova-seed) and other seed projects.
